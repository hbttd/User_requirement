    var xx;
	$(document).ready(function(){ 
    	xx=[
	        {
		        id: 1,
		        content:"1",
		        name: '早班',
		        start: '2018-03-01'
	        },
	        {
	        	id: 2,
		        emptyid:"2",
	          	name: '中班',
	          	start: '2018-03-07'
	        },
	        {
	            id: 3,
		        emptyid:"3",
	            name: '晚班',
	            start: '2018-03-09'
	        },
	        {
	            id: 4,
		        emptyid:"4",
	            name: '其他',
	            start: '2018-03-16'
	        },
	        {
	            id: 5,
		        emptyid:"5",
		        name: '早班',
		        start: '2018-03-11',
	        },
	        {
	            id: 6,
		        emptyid:"6",
	            name: '晚班',
	            start: '2018-03-12'
	        },
	        {
	            id: 7,
		        emptyid:"7",
	            name: '中班',
	            start: '2018-03-12'
	        },
	        {
	            id: 8,
		        emptyid:"8",
	            name: '其他',
	            start: '2018-03-12'
	        },
	        {
	            id: 9,
		        emptyid:"9",
	            title: '早班',
	            start: '2018-03-12'
	        },
	        {
	            id: 11,
		        emptyid:"10",
	            title: '其他',
	            start: '2018-03-13'
	        },
	        {
	            id: 12,
		        emptyid:"11",
	            title: '晚班',
	            url: 'http://www.baidu.com/',
	            start: '2018-03-28'
	        },
	        {
	            id: 13,
		        emptyid:"1",
	            title: '晚班',
	//          url: 'http://baidu.com/',
	            start: '2018-02-28'
	        },
	        {
		        id: 14,
		        emptyid:"1",
		        title: '早班',
		        start: '2018-04-01'
	        },
	        {
	        	id: 15,
		        emptyid:"2",
	          	title: '中班',
	          	start: '2018-04-07'
	        },
	        {
	            id: 16,
		        emptyid:"3",
	            title: '晚班',
	            start: '2018-04-09'
	        },
	        {
	            id: 17,
		        emptyid:"4",
	            title: '其他',
	            start: '2018-04-16'
	        },
	        {
	            id: 18,
		        emptyid:"5",
		        title: '早班',
		        start: '2018-04-11',
	        },
	        {
	            id: 19,
		        emptyid:"6",
	            title: '晚班',
	            start: '2018-04-12'
	        },
	        {
	            id: 20,
		        emptyid:"7",
	            title: '中班',
	            start: '2018-04-12'
	        },
	        {
	            id: 21,
		        emptyid:"8",
	            title: '其他',
	            start: '2018-04-12'
	        },
	        {
	            id: 22,
		        emptyid:"9",
	            title: '早班',
	            start: '2018-04-12'
	        },
	        {
	            id: 23,
		        emptyid:"10",
	            title: '其他',
	            start: '2018-04-13'
	        },
	        {
	            id: 24,
		        emptyid:"11",
	            title: '晚班',
	            url: 'http://www.baidu.com/',
	            start: '2018-04-28'
	        },
	        {
	            id: 25,
		        emptyid:"1",
	            title: '晚班',
	//          url: 'http://baidu.com/',
	            start: '2018-04-28'
	        }
	        
	    ];
	    
	    
	    for(i=0;i<xx.length;i++){
	    	var html="<tr><td>"+xx[i].id+"</td><td>"+xx[i].emptyid+"</td><td>"+xx[i].name+"</td><td>"+xx[i].url+"</td><td>"+xx[i].start+"</td></tr>";
	    	$("#example tbody").append(html);
	    }
	    
	    $('#example').DataTable( {
	        dom: 'Bfrtip',
	        language: {  
                emptyTable: '没有数据',  
                loadingRecords: '加载中...',  
                processing: '查询中...',  
                search: '检索:',  
                lengthMenu: '每页 _MENU_ 件',  
                zeroRecords: '没有数据',  
                paginate: {  
                    'first':      '第一页',  
                    'last':       '最后一页',  
                    'next':       '下一页',  
                    'previous':   '上一页'  
            	},  
	            info: '第 _PAGE_ 页 / 总 _PAGES_ 页',  
	            infoEmpty: '没有数据',  
	            infoFiltered: '(过滤总件数 _MAX_ 条)',
	        },
	    } );
	});

	
function showinfo(){
xx[xx.length]=
	        {
	            id: 36,
		        emptyid:"0",
	            name: '晚班',
	            start: '2017-04-09'
	        };
		/*$("#example tbody").empty();		
		   
			alert("hcy");	    
		for(i=0;i<xx.length;i++){
	    	var html="<tr><td>"+xx[i].id+"</td><td>"+xx[i].emptyid+"</td><td>"+xx[i].name+"</td><td>"+xx[i].url+"</td><td>"+xx[i].start+"</td></tr>";
	    	$("#example tbody").append(html);}
var x={ 
				id: 36,
		        emptyid:"0",
	            title: '晚班',
	            start: '2017-04-09'
				};			
xx.unshift(x);		$("#example tbody").empty();		
		   
			alert("hcy");	    
		for(i=0;i<xx.length;i++){
	    	var html="<tr><td>"+xx[i].id+"</td><td>"+xx[i].emptyid+"</td><td>"+xx[i].name+"</td><td>"+xx[i].url+"</td><td>"+xx[i].start+"</td></tr>";
	    	$("#example tbody").html(html);}*/
			
			
}
