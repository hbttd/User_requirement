		var indexedDB = window.indexedDB || window.webkitIndexedDB || window.mozIndexedDB || window.msIndexedDB; 
		var dbName="user1DB";//数据库名
		var dbVersion=1;//版本号
		var storeName="commentStore";//数据仓库名称
		var idb=null;
		init();
		//代码初始化
		function init(){
			var dbRequest=indexedDB.open(dbName,dbVersion);
			dbRequest.onsuccess=function(e){
				idb=e.target.result;//获取连接成功时的数据库对象
				alert("数据库连接成功。");			
			};
			dbRequest.onerror=function(e){
				alert('数据库连接失败！');
			};
			dbRequest.onupgradeneeded=function(e){
				idb=e.target.result;
				if(!idb.objectStoreNames.contains(storeName)){
					var optionalParameters={
						keyPath:"id",
						autoIncrement:true
					};
                   var objectStore=idb.createObjectStore(storeName,optionalParameters);
				   alert("对象仓库创建成功！");			
                }
				var tx=e.target.transaction;
				alert("数据库版本更新成功！版本"+e.oldVersion+"=>版本"+e.newVersion);
			};

			var u=[{
				user:"李红"，
				password:123456;
				tel:1232432
			},{
				user:"张三"，
				password:654321;
				tel:1232432
			},{
				user:"小小"，
				password:666666;
				tel:1232432
			}];

			for(var i=0;i<u.length;i++)
			{
				var tx=idb.transaction(storeName,'readwrite'); 
				var objectStore = tx.objectStore(storeName); 
				objectStore.add(comment);
			}
		}
		//定义保存数据函数
		function saveuData(){
			//获得表单数据及当前日期
			var user=document.getElementById("user");
			var passwd=document.getElementById("passwd");
			var tel=document.getElementById("tel");
			var comment={
				user:user.value,
				passwd:passwd.value,
				tel:tel.value
			};
/*			var comment=[{
				goodsName:goodsName.value,
				goodsComment:goodsComment.value,
				goodsGrade:goodsGrade.value,
				time:time
			}];*/
			var tx=idb.transaction(storeName,'readwrite'); 
			tx.oncomplete=function(){
				alert("数据保存成功");
			};
			tx.onabort = function() {
	            alert("数据保存失败");
	        };
			var objectStore = tx.objectStore(storeName); 
			objectStore.add(comment);
		}
		function showuData(){
			//清空数据表格
			var showBody=document.getElementById("showBody");
			showBody.innerHTML="";
			var tx=idb.transaction(storeName,'readonly'); 
			var objectStore= tx.objectStore(storeName); 
			var request=objectStore.openCursor();
			request.onsuccess = function(e) {  
				var cursor = e.target.result;  
				if (cursor) {  
					var tableRow=showBody.insertRow(0);
					tableRow.insertCell(0).innerHTML=cursor.value.user;
					tableRow.insertCell(1).innerHTML=cursor.value.passwd;
					tableRow.insertCell(2).innerHTML=cursor.value.tel;
					cursor.continue();  
				} else {  
					console.log("检索结束!");  
				}  
			};
			request.onerror=function(e){
				console.log("检索失败!");  
			};
		}

		
		//将长整形日期数据格式化显示
		function getFormatTime(myDateTime){	
			var myDate=new Date(myDateTime);
			var dateStr="";
			var year=myDate.getFullYear();
			var month=myDate.getMonth()+1;
			var date=myDate.getDate();
			var hour=myDate.getHours();
			var minute=myDate.getMinutes();
			var second=myDate.getSeconds();
			dateStr=dateStr+year+"年"+month+"月"+date+"日 "+hour+":"+minute+":"+second+"<br/>";
			return dateStr;
		}