		var indexedDB = window.indexedDB || window.webkitIndexedDB || window.mozIndexedDB || window.msIndexedDB; 
		var dbName="guideDB";//数据库名
		var dbVersion=1;//版本号
		var storeName="commentStore";//数据仓库名称
		var idb=null;
		init();
		//代码初始化
		function init(){
			var dbRequest=indexedDB.open(dbName,dbVersion);
			dbRequest.onsuccess=function(e){
				idb=e.target.result;//获取连接成功时的数据库对象
				//alert("数据库连接成功。");			
			};
			dbRequest.onerror=function(e){
				//alert('数据库连接失败！');
			};
			dbRequest.onupgradeneeded=function(e){
				idb=e.target.result;
				if(!idb.objectStoreNames.contains(storeName)){
					var optionalParameters={
						keyPath:"id",
						autoIncrement:true
					};
                   var objectStore=idb.createObjectStore(storeName,optionalParameters);
				   //alert("对象仓库创建成功！");			
                }
				var tx=e.target.transaction;
				//alert("数据库版本更新成功！版本"+e.oldVersion+"=>版本"+e.newVersion);
			};
		}
		//定义保存数据函数
		function saveData(){
			//获得表单数据及当前日期
			var gname=document.getElementById("gname");
			var gsex=document.getElementById("gsex");
			var company=document.getElementById("company");
			var pinglun=document.getElementById("pinglun");
			var selProvince=document.getElementById("selProvince");
			var time=new Date().getTime();
			var comment={
				gname:gname.value,
				gsex:gsex.value,
				company:company.value,
				pinglun:pinglun.value,
				selProvince:selProvince.value,
				time:time
			};
/*			var comment=[{
				goodsName:goodsName.value,
				goodsComment:goodsComment.value,
				goodsGrade:goodsGrade.value,
				time:time
			}];*/
			var tx=idb.transaction(storeName,'readwrite'); 
			tx.oncomplete=function(){
				//alert("数据保存成功");
			};
			tx.onabort = function() {
	            //alert("数据保存失败");
	        };
			var objectStore = tx.objectStore(storeName); 
			objectStore.add(comment);
		}
		function showData(){
			//清空数据表格
			var showBody=document.getElementById("showBody");
			showBody.innerHTML="";
			var tx=idb.transaction(storeName,'readonly'); 
			var objectStore= tx.objectStore(storeName); 
			var request=objectStore.openCursor();
			request.onsuccess = function(e) {  
				var cursor = e.target.result;  
				if (cursor) {  
					var tableRow=showBody.insertRow(0);
					tableRow.insertCell(0).innerHTML=cursor.value.gname;
					tableRow.insertCell(1).innerHTML=cursor.value.gsex;
					tableRow.insertCell(2).innerHTML=cursor.value.company;
					tableRow.insertCell(3).innerHTML=selProvince(cursor.value.selProvince);
					tableRow.insertCell(4).innerHTML=cursor.value.pinglun;
					tableRow.insertCell(5).innerHTML=getFormatTime(cursor.value.time);
/*					tableRow.insertCell(0).innerHTML=cursor.value[0].SName;
					tableRow.insertCell(1).innerHTML=cursor.value[1].Sage;
					tableRow.insertCell(2).innerHTML=cursor.value[2].Snum;
					tableRow.insertCell(3).innerHTML=cursor.value[3].Ssex;
					tableRow.insertCell(4).innerHTML=cursor.value[4].Saddress;
					tableRow.insertCell(5).innerHTML=createStar(cursor.value[5].Sgrade);
					tableRow.insertCell(6).innerHTML=getFormatTime(cursor.value[6].time);*/
					cursor.continue();  
				} else {  
					console.log("检索结束!");  
				}  
			};
			request.onerror=function(e){
				console.log("检索失败!");  
			};
		}


		function showDatam(){
			//清空数据表格
			var showBody=document.getElementById("showbodym");
			showBody.innerHTML="";
			var tx=idb.transaction(storeName,'readonly'); 
			var objectStore= tx.objectStore(storeName); 
			var request=objectStore.openCursor();
			request.onsuccess = function(e) {  
				var cursor = e.target.result;  
				if (cursor) {  
					var tableRow=showBody.insertRow(0);
					tableRow.insertCell(0).innerHTML=selProvince(cursor.value.selProvince);
					tableRow.insertCell(1).innerHTML=cursor.value.gname;
					tableRow.insertCell(2).innerHTML=cursor.value.company;
					tableRow.insertCell(3).innerHTML=getFormatTime(cursor.value.time);
					cursor.continue();  
				} else {  
					console.log("检索结束!");  
				}  
			};
			request.onerror=function(e){
				console.log("检索失败!");  
			};
		}

		function deleteData(databaseName){
			var request=indexedDB.deleteDatabase(databaseName);
			//清空数据表格
			var showBody=document.getElementById("showBody");
			showBody.innerHTML="";
		}
		function selProvince(selProvince){
			var Province=selProvince;
			
			return Province;
		}

		
		//将长整形日期数据格式化显示
		function getFormatTime(myDateTime){	
			var myDate=new Date(myDateTime);
			var dateStr="";
			var year=myDate.getFullYear();
			var month=myDate.getMonth()+1;
			var date=myDate.getDate();
			var hour=myDate.getHours();
			var minute=myDate.getMinutes();
			var second=myDate.getSeconds();
			dateStr=dateStr+year+"年"+month+"月"+date+"日 "+hour+":"+minute+":"+second+"<br/>";
			return dateStr;
		}